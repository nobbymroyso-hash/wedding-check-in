Wedding Check-In App Starter

Netlify:
Build command: npm run build
Publish directory: dist

Steps:
1. Create Firebase project.
2. Enable Firestore.
3. Replace firebase config.
4. Deploy to Netlify.
